// Turns raw page data into plain-language checks. status: good | warn | bad
const STOP = new Set(('und oder aber auch nicht sich eine einer eines einem einen sind wird werden wurde haben hatte dass dies diese dieser dieses ' +
  'sowie bei mit von für fuer auf aus nach über ueber unter zum zur den dem der die das des ein ihre ihren ihrer unser unsere unserer ' +
  'the and for are but not you your with that this have has was were from they their will can all any more one our out new about into than then them its sie wir ihr kann können koennen mehr wie als wenn nur noch schon durch einen alle allen jede jeden jeder jedes ihnen unseren ' +
  'weitere weiteren mehr hier mein meine dein deine sein seine seiner ihm ihn war waren ist im in am an es zu').split(' '));

function topTerms(text, n = 6) {
  const counts = new Map();
  for (const w of text.toLowerCase().match(/[a-zäöüéèà]{5,}/g) || []) {
    if (STOP.has(w)) continue;
    counts.set(w, (counts.get(w) || 0) + 1);
  }
  return [...counts].filter(([, c]) => c > 1).sort((a, b) => b[1] - a[1]).slice(0, n);
}

function runChecks(d, lang) {
  const t = (de, en) => (lang === 'de' ? de : en);
  const C = [];
  // status: good | warn | bad. value = what is there. note = short judgement.
  const add = (status, title, value, note, what, why, todo) =>
    C.push({ status, title, value, note, what, why, todo: status === 'good' ? '' : todo });
  const ok = (c) => (c ? 'good' : 'warn');
  const noValue = t('fehlt', 'missing');

  const noindex = /noindex/.test(d.robotsMeta) || d.robotsBlocksAll;
  add(d.status >= 400 ? 'bad' : d.status >= 300 ? 'warn' : d.status ? 'good' : 'warn', 'Status', d.status ? String(d.status) : t('unbekannt', 'unknown'),
    d.status >= 400 ? t('Fehlerseite', 'error page') : d.status >= 300 ? t('Weiterleitung', 'redirect') : '',
    t('Der Antwortcode des Servers. 200 heisst: Seite ist erreichbar.', 'The server response code. 200 means the page is reachable.'),
    t('Bei 4xx oder 5xx nimmt Google die Seite nicht auf.', 'With 4xx or 5xx Google will not index the page.'),
    t('Fehlerursache beheben oder die Adresse per 301 auf die richtige Seite umleiten.', 'Fix the error, or 301-redirect the address to the right page.'));
  add(noindex ? 'bad' : 'good', t('Indexierbar', 'Indexable'), noindex ? t('Nein, gesperrt', 'No, blocked') : t('Ja', 'Yes'), d.robotsMeta.trim() ? 'robots: ' + d.robotsMeta.trim() : '',
    t('«noindex» oder eine Sperre in robots.txt versteckt die Seite vor Google.', '"noindex" or a block in robots.txt hides the page from Google.'),
    t('Eine gesperrte Seite erscheint nie in der Suche.', 'A blocked page never appears in search.'),
    t('«noindex» und Sperren in robots.txt entfernen (im CMS meist in den Seiten- oder SEO-Einstellungen).', 'Remove "noindex" and robots.txt blocks (usually in the CMS page or SEO settings).'));
  add(d.canonical ? (d.canonicalSame ? 'good' : 'warn') : 'warn', 'Canonical', d.canonical || t('nicht gesetzt', 'not set'),
    d.canonical && !d.canonicalSame ? t('zeigt auf eine andere Adresse', 'points to a different address') : '',
    t('Die offizielle Adresse dieser Seite, falls sie unter mehreren erreichbar ist.', "This page's official address, in case it is reachable under several."),
    t('Verhindert, dass Google dieselbe Seite doppelt zählt.', 'Stops Google from counting the same page twice.'),
    d.canonical ? t('Prüfen, ob die andere Adresse Absicht ist.', 'Check that the other address is intended.') : t('Canonical-URL der Seite im CMS setzen.', 'Set the canonical URL in the CMS.'));
  add(ok(d.robotsFound), 'robots.txt', d.robotsFound ? (d.robotsTxt.split('\n').filter(Boolean).slice(0, 3).join(' · ') || t('leer', 'empty')) : t('nicht gefunden', 'not found'), '',
    t('Datei, die Suchmaschinen sagt, welche Bereiche sie lesen dürfen.', 'File that tells search engines which areas they may crawl.'),
    t('Ohne sie gilt alles als erlaubt. Mit Fehlern kann sie die ganze Seite sperren.', 'Without it everything is allowed. Mistakes in it can block the whole site.'),
    t('Eine robots.txt anlegen, die mit «Sitemap:» auf die Sitemap zeigt.', 'Add a robots.txt that points to the sitemap with "Sitemap:".'));
  add(ok(d.sitemapFound), 'Sitemap', d.sitemapFound ? d.sitemapUrl : t('nicht gefunden', 'not found'), '',
    t('Liste aller Seiten, die Google kennen soll.', 'List of all pages Google should know.'),
    t('Neue Seiten werden schneller gefunden.', 'New pages are found faster.'),
    t('Sitemap erzeugen und in der Google Search Console einreichen.', 'Generate a sitemap and submit it in Google Search Console.'));

  const tl = d.title.length;
  add(!tl ? 'bad' : tl < 25 || tl > 65 ? 'warn' : 'good', t('Titel', 'Title'), d.title || noValue, t(`${tl} Zeichen · ideal 30–60`, `${tl} characters · ideal 30–60`),
    t('Der Titel im Google-Ergebnis und im Browser-Tab.', 'The title in the Google result and the browser tab.'),
    t('Stärkstes einzelnes Signal für das Thema der Seite, entscheidet mit über den Klick.', 'Strongest single signal for what the page is about, and it drives the click.'),
    tl < 25 ? t('Ausführlicher formulieren: Thema plus Ort oder Angebot.', 'Make it more specific: topic plus place or offer.') : t('Auf rund 60 Zeichen kürzen, sonst schneidet Google ab.', 'Cut to about 60 characters, or Google truncates it.'));
  const dl = d.description.length;
  add(!dl ? 'bad' : dl < 70 || dl > 165 ? 'warn' : 'good', t('Beschreibung', 'Description'), d.description || noValue, t(`${dl} Zeichen · ideal 120–160`, `${dl} characters · ideal 120–160`),
    t('Der graue Text unter dem Titel im Google-Ergebnis (Meta Description).', 'The grey text under the title in the Google result (meta description).'),
    t('Wirkt wie ein Werbetext und bringt mehr Klicks bei gleichem Rang.', 'Works like an ad and earns more clicks at the same rank.'),
    dl < 70 ? t('Zwei Sätze mit Nutzen und Aufforderung, 120–160 Zeichen.', 'Two sentences with a benefit and a call to action, 120–160 characters.') : t('Auf höchstens 160 Zeichen kürzen.', 'Cut to 160 characters at most.'));
  add(d.h1.length === 1 ? 'good' : 'bad', 'H1', d.h1.length ? d.h1.join(' | ') : noValue, d.h1.length === 1 ? '' : t(`${d.h1.length} gefunden, gewünscht 1`, `${d.h1.length} found, want 1`),
    t('Die Hauptüberschrift der Seite.', 'The main heading of the page.'),
    t('Google und Besucher erkennen daran das Thema. Genau eine pro Seite.', 'Google and visitors see the topic from it. Exactly one per page.'),
    d.h1.length ? t('Nur eine Überschrift als H1 auszeichnen, die übrigen als H2/H3.', 'Mark only one heading as H1, the rest as H2/H3.') : t('Eine Hauptüberschrift mit dem Thema ergänzen.', 'Add a main heading that names the topic.'));
  add(d.h2Count >= 2 ? 'good' : 'warn', 'H2', String(d.h2Count), t('siehe Tab «Struktur»', 'see tab "Structure"'),
    t('Zwischenüberschriften gliedern den Text.', 'Subheadings break the text into sections.'),
    t('Sie machen die Seite lesbar und zeigen Google die Unterthemen.', 'They make the page readable and show Google the subtopics.'),
    t('Längere Texte in Abschnitte gliedern.', 'Break longer text into sections.'));
  add(d.wordCount >= 300 ? 'good' : d.wordCount >= 150 ? 'warn' : 'bad', t('Wörter', 'Words'), String(d.wordCount), t('Richtwert ab 300', 'guide: 300+'),
    t('Wortzahl des Hauptinhalts ohne Cookie-Banner.', 'Word count of the main content, without cookie banners.'),
    t('Sehr dünne Seiten beantworten die Suchfrage selten.', 'Very thin pages rarely answer the search question.'),
    t('Die Fragen der Zielgruppe beantworten, mehr Substanz ergänzen.', 'Answer the audience\'s questions and add substance.'));
  add(d.imageCount === 0 || d.imagesNoAlt === 0 ? 'good' : d.imagesNoAlt / d.imageCount > 0.3 ? 'bad' : 'warn', t('Bilder', 'Images'),
    t(`${d.imageCount} · ${d.imagesNoAlt} ohne Alt`, `${d.imageCount} · ${d.imagesNoAlt} without alt`), t('siehe Tab «Bilder»', 'see tab "Images"'),
    t('Alt-Text ist die Bildbeschreibung für Screenreader und Google.', 'Alt text is the image description for screen readers and Google.'),
    t('Hilft Barrierefreiheit und der Bildersuche.', 'Helps accessibility and image search.'),
    t('Bei jedem Bild eine kurze Beschreibung eintragen, Dekobilder als dekorativ markieren.', 'Add a short description to each image, mark decorative ones as decorative.'));
  add(d.emptyLinks === 0 ? 'good' : 'warn', 'Links', t(`${d.linkCount} · ${d.internalCount} intern · ${d.externalCount} extern · ${d.nofollowCount} nofollow`, `${d.linkCount} · ${d.internalCount} internal · ${d.externalCount} external · ${d.nofollowCount} nofollow`),
    d.emptyLinks ? t(`${d.emptyLinks} ohne Text`, `${d.emptyLinks} without text`) : t('siehe Tab «Links»', 'see tab "Links"'),
    t('Verbindungen zu anderen Seiten. «nofollow» heisst: Google soll dem Link nicht folgen.', 'Connections to other pages. "nofollow" tells Google not to follow the link.'),
    t('Interne Links zeigen, welche Seiten wichtig sind. Links ohne Text sind unverständlich.', 'Internal links show which pages matter. Links without text are unreadable.'),
    t('Bei Bild-Links eine Beschreibung ergänzen.', 'Add a description to image links.'));

  add(d.https ? 'good' : 'bad', 'HTTPS', d.https ? t('Ja', 'Yes') : t('Nein', 'No'), '',
    t('Verschlüsselte Verbindung (Schloss in der Adresszeile).', 'Encrypted connection (padlock in the address bar).'),
    t('Browser warnen vor unsicheren Seiten, Google wertet es ab.', 'Browsers warn about insecure pages and Google ranks them lower.'),
    t('SSL aktivieren und auf https umleiten.', 'Enable SSL and redirect to https.'));
  add(d.viewport ? 'good' : 'bad', 'Mobile', d.viewportContent || noValue, '',
    t('Hinweis im Seitencode, wie die Seite aufs Handy skaliert wird.', 'Tag in the page code that says how to scale the page on phones.'),
    t('Google bewertet zuerst die Handy-Version.', 'Google evaluates the mobile version first.'),
    t('viewport-Eintrag im Seitenkopf ergänzen.', 'Add a viewport tag to the page head.'));
  add(d.lang ? 'good' : 'warn', t('Sprache', 'Language'), d.lang || t('nicht angegeben', 'not set'), d.hreflang.length ? `hreflang: ${d.hreflang.length}` : '',
    t('Sprache des Inhalts im Seitencode.', 'Language of the content, declared in the page code.'),
    t('Google zeigt die Seite den passenden Nutzern.', 'Google shows the page to the right users.'),
    t('Sprache im CMS bzw. im html-Tag setzen.', 'Set the language in the CMS or the html tag.'));
  const shareOk = d.ogTitle && d.ogImage;
  add(shareOk ? 'good' : d.ogTitle || d.ogImage ? 'warn' : 'bad', 'Open Graph',
    [d.ogTitle && t('Titel', 'Title'), d.ogDescription && t('Beschreibung', 'Description'), d.ogImage && t('Bild', 'Image')].filter(Boolean).join(' · ') || noValue,
    d.twitterCard ? 'twitter:card ' + d.twitterCard : '',
    t('Vorschaukarte beim Teilen in WhatsApp, LinkedIn, Facebook.', 'Preview card when shared on WhatsApp, LinkedIn, Facebook.'),
    t('Gepflegte Vorschau wirkt professionell und wird häufiger angeklickt.', 'A good preview looks professional and gets more clicks.'),
    t('Titel, Beschreibung und Bild (1200 × 630 px) hinterlegen.', 'Set title, description and image (1200 × 630 px).'));

  const blocks = d.schemaBlocks, broken = blocks.filter((b) => !b.valid);
  const types = [...new Set(blocks.flatMap((b) => b.types))];
  const orgSchema = types.some((x) => /Organization|LocalBusiness|Hospital|Medical|Physician|Person|WebSite|Store|Service/i.test(x));
  add(broken.length ? 'bad' : orgSchema ? 'good' : 'warn', 'Schema.org',
    blocks.length ? (broken.length ? t(`${broken.length} von ${blocks.length} Block ungültig`, `${broken.length} of ${blocks.length} blocks invalid`) : types.join(', ')) : t('keine', 'none'),
    broken.length ? broken[0].error : t('siehe Tab «Schema»', 'see tab "Schema"'),
    t('Unsichtbare Zusatzangaben, die Name, Adresse, Telefon und mehr für Google lesbar machen.', 'Invisible extra data that makes name, address, phone and more readable for Google.'),
    broken.length ? t('Ungültiger Code wird von Google komplett ignoriert, die Angaben bringen dann nichts.', 'Google ignores invalid code entirely, so the data does nothing.') : t('Ermöglicht Rich Results und Infokarten in Suche und Karte.', 'Enables rich results and info cards in search and maps.'),
    broken.length ? t('JSON korrigieren: typografische Anführungszeichen („ “) durch gerade (") ersetzen, Komma nach der letzten Eigenschaft entfernen. Danach im Tab «Schema» prüfen.', 'Fix the JSON: replace typographic quotes („ “ “ ”) with straight ("), remove the comma after the last property. Then recheck in the "Schema" tab.')
      : t('Passenden Typ (z. B. Organization, LocalBusiness, MedicalClinic) als JSON-LD einbauen.', 'Add a fitting type (e.g. Organization, LocalBusiness, MedicalClinic) as JSON-LD.'));

  const order = { bad: 0, warn: 1, good: 2 };
  const todo = C.filter((c) => c.status !== 'good').length;
  const terms = topTerms(d.text).map(([word, count]) => ({
    word, count, inTitle: d.title.toLowerCase().includes(word) || d.h1.join(' ').toLowerCase().includes(word),
  }));
  return { checks: C, todo, total: C.length, terms, order };
}
