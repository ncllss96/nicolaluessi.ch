// Runs inside the open page (injected by popup.js). Must be self-contained.
async function collectPage() {
  const q = (s) => document.querySelector(s);
  const metaName = (n) => (q(`meta[name="${n}" i]`)?.content || '').trim();
  const metaProp = (p) => (q(`meta[property="${p}" i]`)?.content || '').trim();
  const origin = location.origin;

  const root = q('main') || document.body;
  let raw = root.innerText || '';
  for (const el of document.querySelectorAll('[class*="cookie" i],[id*="cookie" i],[class*="consent" i],[id*="consent" i]')) {
    const t = el.innerText;
    if (t && t.length > 20) raw = raw.replace(t, ' ');
  }
  const text = raw.replace(/\s+/g, ' ').trim();
  const words = text.split(' ').filter(Boolean);

  const imgs = [...document.images].filter((i) => (i.currentSrc || i.src) && i.width !== 1);
  const imagesNoAlt = imgs.filter((i) => !i.hasAttribute('alt')).length;

  const links = [...document.querySelectorAll('a[href]')].filter((a) => /^https?:/.test(a.href));
  const host = (u) => new URL(u).hostname.replace(/^www\./, '');
  const internal = links.filter((a) => host(a.href) === location.hostname.replace(/^www\./, ''));
  const emptyLinks = links.filter(
    (a) => !a.textContent.trim() && !a.getAttribute('aria-label') && !a.querySelector('img[alt]:not([alt=""])')
  ).length;

  const jsonLd = [...document.querySelectorAll('script[type="application/ld+json"]')]
    .map((s) => { try { return JSON.parse(s.textContent); } catch { return null; } })
    .filter(Boolean);
  const schemaTypes = jsonLd
    .flatMap((d) => (Array.isArray(d) ? d : d['@graph'] || [d]))
    .map((d) => d['@type'])
    .flat()
    .filter(Boolean);

  const get = async (url, opts) => {
    try { return await fetch(url, { credentials: 'omit', ...opts }); } catch { return null; }
  };

  const robotsRes = await get(origin + '/robots.txt');
  const robotsTxt = robotsRes?.ok ? await robotsRes.text() : '';
  let agents = [], inGroup = false, blocksAll = false;
  for (const raw of robotsTxt.split(/\r?\n/)) {
    const line = raw.split('#')[0].trim();
    const m = line.match(/^([a-z-]+)\s*:\s*(.*)$/i);
    if (!m) continue;
    const k = m[1].toLowerCase(), v = m[2].trim();
    if (k === 'user-agent') { if (inGroup) { agents = []; inGroup = false; } agents.push(v); }
    else { inGroup = true; if (k === 'disallow' && v === '/' && agents.includes('*')) blocksAll = true; }
  }
  const sitemapUrl = (robotsTxt.match(/^sitemap:\s*(\S+)/im) || [])[1] || origin + '/sitemap.xml';
  const sitemapRes = await get(sitemapUrl);

  const headRes = await get(location.href, { method: 'HEAD' });
  const xRobots = headRes?.headers.get('x-robots-tag') || '';

  const clean = (t) => (t || '').replace(/\s+/g, ' ').trim();
  const norm = (u) => u.replace(/#.*$/, '').replace(/\/$/, '');
  const linkRows = links.slice(0, 400).map((a) => ({
    href: a.href,
    text: clean(a.textContent) || a.getAttribute('aria-label') || clean(a.querySelector('img')?.alt) || '',
    internal: host(a.href) === location.hostname.replace(/^www\./, ''),
    nofollow: /nofollow|sponsored|ugc/i.test(a.rel),
  }));
  const schemaBlocks = [...document.querySelectorAll('script[type="application/ld+json"]')].map((s) => {
    let obj = null, error = '';
    try { obj = JSON.parse(s.textContent); } catch (e) { error = String(e.message).replace(/^JSON\.parse: /, ''); }
    const guess = (s.textContent.match(/"@type"\s*:\s*[„“"”]?([A-Za-z]+)/) || [])[1];
    const types = obj ? [obj].flat().flatMap((d) => d['@graph'] || [d]).map((d) => d['@type']).flat().filter(Boolean) : guess ? [guess] : [];
    return { valid: !!obj, error, types, json: obj ? JSON.stringify(obj, null, 2) : s.textContent.trim().slice(0, 2500) };
  });

  return {
    status: headRes ? headRes.status : 0,
    viewportContent: q('meta[name="viewport"]')?.content || '',
    ogDescription: metaProp('og:description'),
    twitterCard: metaName('twitter:card'),
    hreflang: [...document.querySelectorAll('link[rel="alternate"][hreflang]')].map((l) => `${l.hreflang} → ${l.href}`),
    headings: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map((h) => ({ l: +h.tagName[1], t: clean(h.textContent) })).filter((h) => h.t).slice(0, 120),
    linkRows,
    nofollowCount: linkRows.filter((l) => l.nofollow).length,
    externalCount: linkRows.filter((l) => !l.internal).length,
    imageRows: imgs.slice(0, 200).map((i) => ({ src: i.currentSrc || i.src, alt: i.hasAttribute('alt') ? i.getAttribute('alt') : null, w: i.naturalWidth, h: i.naturalHeight })),
    schemaBlocks,
    robotsTxt: robotsTxt.trim().slice(0, 600),
    sitemapUrl,
    canonicalSame: !!q('link[rel="canonical"]') && norm(q('link[rel="canonical"]').href) === norm(location.href),
    url: location.href,
    host: location.hostname,
    https: location.protocol === 'https:',
    lang: document.documentElement.lang || '',
    title: document.title.trim(),
    description: metaName('description'),
    robotsMeta: (metaName('robots') + ' ' + xRobots).toLowerCase(),
    canonical: (q('link[rel="canonical"]')?.href || '').trim(),
    viewport: !!q('meta[name="viewport"]'),
    ogTitle: metaProp('og:title'),
    ogImage: metaProp('og:image'),
    h1: [...document.querySelectorAll('h1')].map((h) => h.textContent.trim()).filter(Boolean),
    h2Count: document.querySelectorAll('h2').length,
    wordCount: words.length,
    text,
    imageCount: imgs.length,
    imagesNoAlt,
    linkCount: links.length,
    internalCount: internal.length,
    emptyLinks,
    schemaTypes,
    robotsFound: !!robotsRes?.ok,
    robotsBlocksAll: blocksAll,
    sitemapFound: !!sitemapRes?.ok,
  };
}
