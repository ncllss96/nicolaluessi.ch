const api = typeof browser !== 'undefined' ? browser : chrome;
const app = document.getElementById('app');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const CHEV = '<svg class="chev" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
const LANG = localStorage.getItem('lang') || ((navigator.language || '').startsWith('de') ? 'de' : 'en');
const t = (de, en) => (LANG === 'de' ? de : en);
const TABS = [['uebersicht', t('Übersicht', 'Overview')], ['struktur', t('Struktur', 'Structure')], ['links', 'Links'], ['bilder', t('Bilder', 'Images')], ['schema', 'Schema']];
let state = { d: null, r: null, tab: 'uebersicht', linkFilter: 'alle' };

function row(c) {
  return `<details><summary><span class="badge ${c.status}"></span>
    <span class="lbl">${esc(c.title)}</span>
    <span class="val"><span class="v">${esc(c.value)}</span>${c.note ? `<span class="n">${esc(c.note)}</span>` : ''}</span>${CHEV}</summary>
    <div class="body">
      <p><b>${t('Was', 'What')}:</b> ${esc(c.what)}</p>
      <p><b>${t('Warum', 'Why')}:</b> ${esc(c.why)}</p>
      ${c.todo ? `<p class="todo"><b>${t('Tun', 'Do')}:</b> ${esc(c.todo)}</p>` : ''}
    </div></details>`;
}

function tabOverview({ r }) {
  const sorted = [...r.checks].sort((a, b) => r.order[a.status] - r.order[b.status]);
  return `<div class="list">${sorted.map(row).join('')}</div>
  ${r.terms.length ? `<h2 class="sh">${t('Häufigste Begriffe', 'Top terms')}</h2><div class="terms">${r.terms.map((t) => `<span class="tag ${t.inTitle ? 'hit' : ''}">${esc(t.word)} <small>${t.count}×</small></span>`).join('')}</div>
  <p class="note">${t('Umrandet: steht auch in Titel oder H1.', 'Outlined: also in title or H1.')}</p>` : ''}`;
}

function tabStructure({ d }) {
  if (!d.headings.length) return '<p class="empty-s">Keine Überschriften gefunden.</p>';
  return `<ul class="outline">${d.headings.map((h) => `<li style="padding-left:${(h.l - 1) * 16}px"><span class="h h${h.l}">H${h.l}</span>${esc(h.t)}</li>`).join('')}</ul>`;
}

function tabLinks({ d }) {
  const f = state.linkFilter;
  const F = { alle: () => true, intern: (l) => l.internal, extern: (l) => !l.internal, nofollow: (l) => l.nofollow, 'ohne text': (l) => !l.text };
  const FL = { alle: t('alle', 'all'), intern: t('intern', 'internal'), extern: t('extern', 'external'), nofollow: 'nofollow', 'ohne text': t('ohne text', 'no text') };
  const rows = d.linkRows.filter(F[f]);
  return `<div class="chips">${Object.keys(F).map((k) => `<button class="chip ${k === f ? 'on' : ''}" data-f="${k}">${FL[k]} <small>${d.linkRows.filter(F[k]).length}</small></button>`).join('')}</div>
  <ul class="rows">${rows.slice(0, 150).map((l) => `<li><span class="txt ${l.text ? '' : 'miss'}">${esc(l.text || t('kein Text', 'no text'))}${l.nofollow ? ' <em>nofollow</em>' : ''}</span><a href="${esc(l.href)}" target="_blank" rel="noreferrer">${esc(l.href.replace(/^https?:\/\/(www\.)?/, ''))}</a></li>`).join('') || '<li class="empty-s">Keine.</li>'}</ul>`;
}

function tabImages({ d }) {
  if (!d.imageRows.length) return `<p class="empty-s">${t('Keine Bilder gefunden.', 'No images found.')}</p>`;
  const sorted = [...d.imageRows].sort((a, b) => (a.alt === null ? 0 : 1) - (b.alt === null ? 0 : 1));
  return `<ul class="rows">${sorted.map((i) => `<li class="img"><img src="${esc(i.src)}" alt=""><span><span class="txt ${i.alt === null ? 'miss' : i.alt === '' ? 'dec' : ''}">${i.alt === null ? t('Alt fehlt', 'alt missing') : i.alt === '' ? t('dekorativ (leer)', 'decorative (empty)') : esc(i.alt)}</span><span class="src">${i.w}×${i.h} · ${esc(i.src.split('/').pop().slice(0, 48))}</span></span></li>`).join('')}</ul>`;
}

function tabSchema({ d }) {
  if (!d.schemaBlocks.length) return `<p class="empty-s">${t('Keine strukturierten Daten (JSON-LD) auf dieser Seite.', 'No structured data (JSON-LD) on this page.')}</p>
    <details class="plain"><summary>${t('Warum das zählt', 'Why it matters')} ${CHEV}</summary><div class="body"><p>${t('Mit Schema.org-Daten kann Google Name, Adresse, Telefon und Öffnungszeiten direkt anzeigen.', 'With schema.org data Google can show name, address, phone and opening hours directly.')}</p></div></details>`;
  return d.schemaBlocks.map((b) => `<details class="plain" ${b.valid ? "" : "open"}><summary><span class="badge ${b.valid ? 'good' : 'bad'}"></span><span class="lbl wide">${esc(b.types.join(', ') || t('Unbekannt', 'Unknown'))}</span>${b.valid ? '' : `<span class="n">${t('ungültig', 'invalid')}</span>`}${CHEV}</summary>${b.valid ? '' : `<p class="err">${esc(b.error)}</p>`}<pre>${esc(b.json)}</pre></details>`).join('');
}

function render() {
  const { d, r, tab } = state;
  const good = r.total - r.todo;
  document.getElementById('host').textContent = d.host.replace(/^www\./, '');
  const views = { uebersicht: tabOverview, struktur: tabStructure, links: tabLinks, bilder: tabImages, schema: tabSchema };
  const sorted = [...r.checks].sort((a, b) => r.order[a.status] - r.order[b.status]);
  app.innerHTML = `
  <div class="sum">
    <div class="count"><span class="num">${r.todo}</span><span class="cl">${t('zu verbessern', 'to improve')}</span></div>
    <div class="count ok"><span class="num">${good}</span><span class="cl">${t('in Ordnung', 'ok')}</span></div>
    <div class="bars">${sorted.map((c) => `<i class="${c.status}"></i>`).join('')}</div>
  </div>
  <nav class="tabs">${TABS.map(([k, l]) => `<button class="${k === tab ? 'on' : ''}" data-t="${k}">${l}</button>`).join('')}</nav>
  <div class="pane">${views[tab](state)}</div>
  <footer><span>${t('Nur diese Seite', 'This page only')} · <a class="help" href="https://nicolaluessi.ch/extension/" target="_blank" rel="noreferrer">${t('Hilfe', 'Help')}</a> · <button class="lang" id="lang">${LANG === 'de' ? 'EN' : 'DE'}</button></span><button class="btn" id="again">${t('Neu prüfen', 'Recheck')}</button></footer>`;
  app.querySelectorAll('[data-t]').forEach((b) => (b.onclick = () => { state.tab = b.dataset.t; render(); }));
  app.querySelectorAll('[data-f]').forEach((b) => (b.onclick = () => { state.linkFilter = b.dataset.f; render(); }));
  document.getElementById('again').onclick = run;
  document.getElementById('lang').onclick = () => { localStorage.setItem('lang', LANG === 'de' ? 'en' : 'de'); location.reload(); };
}

async function run() {
  app.innerHTML = `<p class="loading">${t('Seite wird geprüft', 'Checking page')}</p>`;
  try {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url || !/^https?:/.test(tab.url)) throw new Error('unsupported');
    const [{ result }] = await api.scripting.executeScript({ target: { tabId: tab.id }, func: collectPage });
    state.d = result; state.r = runChecks(result, LANG);
    render();
  } catch (e) {
    document.getElementById('host').textContent = '';
    app.innerHTML = `<div class="empty"><h2>${t('Hier kann ich nichts <em>prüfen.</em>', 'Nothing to <em>check</em> here.')}</h2>
      <p>${t('Öffnen Sie eine normale Webseite und klicken Sie erneut auf das Herz.', 'Open a regular web page and click the heart again.')}</p></div>`;
  }
}
run();
